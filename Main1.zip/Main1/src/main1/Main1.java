package main1;
/**
 *
 * @author sp21-bse-065
 */
public class Main1 {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle();
        rectangle.draw();

        Shape square = new Square();
        square.draw();

        Shape roundedRectangle = new RoundedRectangle();
        roundedRectangle.draw();

        Shape roundedSquare = new RoundedSquare();
        roundedSquare.draw();
    }
}    
